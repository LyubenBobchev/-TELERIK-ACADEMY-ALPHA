﻿using OlympicGames.Core;
using OlympicGames.Core.Factories;
using OlympicGames.Olympics.Enums;

namespace OlympicGames
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            // Don not touch here (Magic Unicorns)
            Engine.Instance.Run();

        }
    }
}
