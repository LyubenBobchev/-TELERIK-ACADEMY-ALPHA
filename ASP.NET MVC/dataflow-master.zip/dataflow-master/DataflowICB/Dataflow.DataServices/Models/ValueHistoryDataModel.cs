﻿using System;

namespace Dataflow.DataServices.Models
{
    public class ValueHistoryDataModel
    {       
        public DateTime Date { get; set; }

        public double Value { get; set; }
    }
}
