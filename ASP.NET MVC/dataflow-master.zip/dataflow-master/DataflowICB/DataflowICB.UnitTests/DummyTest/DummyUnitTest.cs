﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DataflowICB.UnitTests
{
    [TestClass]
    public class DummyUnitTest
    {
        [TestMethod]
        public void TestingJenkins()
        {

        }
    }
}
