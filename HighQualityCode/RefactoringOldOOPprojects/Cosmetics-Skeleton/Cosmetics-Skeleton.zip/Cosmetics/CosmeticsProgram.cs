﻿using Cosmetics.Engine;
using Cosmetics.Products;
using System;
using System.Data;

namespace Cosmetics
{
    public class CosmeticsProgram
    {
        public static void Main()
        {
           CosmeticsEngine.Instance.Start();
            
        }
    }


}
