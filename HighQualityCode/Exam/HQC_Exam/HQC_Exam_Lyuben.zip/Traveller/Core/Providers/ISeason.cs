﻿namespace Traveller.Core
{
    internal interface ISeason
    {
    }
}