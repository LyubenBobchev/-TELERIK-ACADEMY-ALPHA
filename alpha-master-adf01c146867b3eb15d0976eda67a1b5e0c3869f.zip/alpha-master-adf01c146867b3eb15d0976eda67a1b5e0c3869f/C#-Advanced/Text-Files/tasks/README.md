# Telerik Academy Alpha
## Text files
====================
