# Line numbers

## Description
Write a program that reads a text file and inserts line numbers in front of each of its lines.
The result should be written to another text file.
