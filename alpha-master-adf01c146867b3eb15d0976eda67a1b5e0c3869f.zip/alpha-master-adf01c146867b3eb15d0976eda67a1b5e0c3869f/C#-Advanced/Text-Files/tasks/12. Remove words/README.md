# Remove words

## Description
Write a program that removes from a text file all words listed in given another text file.
Handle all possible exceptions in your methods.
