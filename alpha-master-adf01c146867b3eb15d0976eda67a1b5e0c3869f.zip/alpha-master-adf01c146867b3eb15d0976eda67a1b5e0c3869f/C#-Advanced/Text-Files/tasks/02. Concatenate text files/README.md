# Concatenate text files

## Description
Write a program that concatenates two text files into another text file.
