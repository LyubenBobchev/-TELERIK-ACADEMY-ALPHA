# Odd lines

## Description
Write a program that reads a text file and prints on the console its odd lines.
