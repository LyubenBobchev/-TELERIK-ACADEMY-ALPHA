# Sort by string length

## Description
You are given an array of strings. Write a method that sorts the array by the length of its elements (the number of characters composing them).

## Submission
- You do not have to submit anything for this problem
