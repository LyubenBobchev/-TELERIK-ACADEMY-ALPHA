# Telerik Academy Alpha
## Multidimensional Arrays
=================================