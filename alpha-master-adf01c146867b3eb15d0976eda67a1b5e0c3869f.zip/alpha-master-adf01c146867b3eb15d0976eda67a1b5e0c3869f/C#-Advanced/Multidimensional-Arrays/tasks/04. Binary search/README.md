# Binary search

## Description
Write a program, that reads from the console an array of `N` integers and an integer `K`, sorts the array and using the method `Array.BinSearch()` finds the largest number in the array which is &#8804; `K`. 

## Submission
- You do not have to submit anything for this problem
