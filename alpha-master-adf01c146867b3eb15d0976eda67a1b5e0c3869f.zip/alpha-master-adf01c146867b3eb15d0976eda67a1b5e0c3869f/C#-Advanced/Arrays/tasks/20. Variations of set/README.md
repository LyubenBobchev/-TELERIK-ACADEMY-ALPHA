# Variations of set

## Description
Write a program that reads two numbers `N` and `K` and generates all the variations of `K` elements from the set [`1..N`].

## Sample tests

| N | K |                                      result                                      |
|:-:|:-:|:--------------------------------------------------------------------------------:|
| 3 | 2 | `{1, 1}` <br> `{1, 2}` <br> `{1, 3}` <br> `{2, 1}` <br> `{2, 2}` <br> `{2, 3}` <br> `{3, 1}` <br> `{3, 2}` <br> `{3, 3}` |

## Submission
- You do not have to submit anything for this problem
