# Telerik Academy Alpha
## Arrays
================
