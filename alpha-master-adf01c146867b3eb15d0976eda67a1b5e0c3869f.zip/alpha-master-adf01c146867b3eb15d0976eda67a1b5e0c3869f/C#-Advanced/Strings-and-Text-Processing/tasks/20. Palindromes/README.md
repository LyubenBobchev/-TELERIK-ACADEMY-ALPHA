# Palindromes

## Description
Write a program that extracts from a given text all palindromes, e.g. `ABBA`, `lamal`, `exe`.

## Submission
- You do not have to submit anything for this problem
