# Telerik Academy Alpha
## Processing
====================
