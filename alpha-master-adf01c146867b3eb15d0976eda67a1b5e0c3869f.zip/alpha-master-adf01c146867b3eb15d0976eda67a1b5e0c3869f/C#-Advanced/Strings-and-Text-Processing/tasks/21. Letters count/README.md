# Letters count

## Description
Write a program that reads a string from the console and prints all different letters in the string along with information how many times each letter is found. 

## Submission
- You do not have to submit anything for this problem
