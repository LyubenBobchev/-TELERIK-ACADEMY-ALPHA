# Extract e-mails

## Description
Write a program for extracting all email addresses from given text.
All sub-strings that match the format `<identifier>@<host>…<domain>` should be recognized as emails.

## Submission
- You do not have to submit anything for this problem
