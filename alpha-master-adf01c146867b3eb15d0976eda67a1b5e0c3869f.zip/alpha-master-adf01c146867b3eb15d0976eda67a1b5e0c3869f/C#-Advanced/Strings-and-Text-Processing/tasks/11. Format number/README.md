# Format number

## Description
Write a program that reads a number and prints it as a decimal number, hexadecimal number, percentage and in scientific notation.
Format the output aligned right in 15 symbols.

## Submission
- You do not have to submit anything for this problem
