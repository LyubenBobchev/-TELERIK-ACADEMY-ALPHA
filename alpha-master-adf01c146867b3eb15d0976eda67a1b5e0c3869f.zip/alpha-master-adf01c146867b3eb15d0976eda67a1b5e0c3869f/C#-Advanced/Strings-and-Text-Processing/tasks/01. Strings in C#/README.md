# Strings in C&#35;

## Description
Describe the strings in C#.
What is typical for the string data type?
Describe the most important methods of the String class.

## Submission
- You do not have to submit anything for this problem
