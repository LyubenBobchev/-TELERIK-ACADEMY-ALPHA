# Telerik Academy Alpha
## Methods
=================