# Subtracting polynomials

## Description
Extend the previous program to support also subtraction and multiplication of polynomials.

## Submission
- You do not have to submit anything for this problem
