# Number calculations

## Description
Modify your last program and try to make it work for any number type, not just integer (e.g. decimal, float, byte, etc.)
Use generic method (read in Internet about generic methods in C#).

## Submission
- You do not have to submit anything for this problem
